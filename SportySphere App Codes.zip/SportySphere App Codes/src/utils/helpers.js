export const formatTimeAgo = (isoString) => { /* function code from the uploaded file */ };
export const formatOdds = (odds) => { /* function code from the uploaded file */ };
