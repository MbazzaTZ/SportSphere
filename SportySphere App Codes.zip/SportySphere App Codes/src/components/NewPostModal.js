components/
│   │   ├── 
│   │   ├── 
│   │   ├──
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   ├── NewPostModal.js
│   │   ├── LiveTab.js
│   │   ├── MessageItem.js
│   │   ├── Messaging.js
│   │   ├── LoginPage.js
│   │   ├── LiveMatchScreen.js
│   │   ├── ShopProductCard.js
│   │   ├── ShopModal.js
│   │   ├── OnlineShop.js
│   │   ├── PaymentModal.js
│   │   ├── OrdersPage.js
│   │   ├── ProfilePage.js
│   │   ├── EditProfileModal.js
│   │   └── StoryViewer.js
│   ├── data/
│   │   └── allData.js
│   ├── utils/
│   │   └── formatters.js
│   ├── App.js
│   └── index.js
└── package.json (and other project config files)